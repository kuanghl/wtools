// ── MathJax 公式渲染 ──
// 检测 HTML 文本节点中的 LaTeX 公式（\( ... \) 行内；\[ ... \] / $$ ... $$ 块级），
// 通过 MathJax 渲染为自包含 SVG（fontCache: none，无共享字体引用，微信保存后可离线显示）。
// 输出结构与 mpMath 一致（span[data-formula] 包裹 mjx-container），若同时安装 mpMath 可再次编辑。
// 渲染失败的公式保留原文并计数，不阻断后续流程。

let mathQueue = Promise.resolve();

const MATH_FORMULA_SOURCE = String.raw`\\\[([\s\S]+?)\\\]|\$\$([\s\S]+?)\$\$|\\\(([\s\S]+?)\\\)`;

function matchFormulas(text) {
    const matches = [];
    const re = new RegExp(MATH_FORMULA_SOURCE, 'g');
    let m;
    while ((m = re.exec(text)) !== null) {
        const display = m[1] !== undefined || m[2] !== undefined;
        const tex = (m[1] !== undefined ? m[1] : m[2] !== undefined ? m[2] : m[3]).trim();
        if (!tex) continue;
        matches.push({ start: m.index, end: re.lastIndex, tex, display });
    }
    return matches;
}

function collectFormulaTextNodes(container) {
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
            const tag = node.parentElement ? node.parentElement.tagName : '';
            if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'TEXTAREA') return NodeFilter.FILTER_REJECT;
            return matchFormulas(node.nodeValue).length > 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
        }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    return nodes;
}

// 同步检测：返回公式数量，用于决定是否显示渲染进度
function detectFormulasInHtml(html) {
    const container = document.createElement('div');
    container.innerHTML = html;
    let total = 0, display = 0, inline = 0;
    for (const node of collectFormulaTextNodes(container)) {
        for (const m of matchFormulas(node.nodeValue)) {
            total++;
            if (m.display) display++; else inline++;
        }
    }
    return { total, display, inline };
}

async function renderOneFormula(tex, display) {
    const MathJax = window.MathJax;
    if (!MathJax || !MathJax.startup || !MathJax.startup.promise) {
        throw new Error('MathJax 未加载');
    }
    await MathJax.startup.promise;
    // MathJax 有全局状态（宏表、活动文档），必须先复位再串行渲染
    MathJax.texReset();
    const options = MathJax.getMetricsFor(document.body);
    options.display = display;
    const node = await MathJax.tex2svgPromise(tex, options);
    if (!node.querySelector('svg') || node.querySelector('[data-mml-node="merror"]')) {
        throw new Error('LaTeX 语法错误');
    }
    node.querySelectorAll('mjx-assistive-mml').forEach(el => el.remove());
    if (display) {
        node.style.cssText = 'overflow-x:auto; outline:0; display:block; text-align:center; margin:15px 0;';
        node.querySelector('svg').style.cssText = 'height:auto; max-width:300% !important;';
    }
    node.setAttribute('data-formula', tex);
    MathJax.startup.document.clear();
    MathJax.startup.document.updateDocument();

    const wrapper = document.createElement('span');
    wrapper.style.cursor = 'pointer';
    wrapper.appendChild(node);
    return wrapper;
}

// 渲染整段 HTML，Promise 返回 { html, rendered, failed }；无公式时立即返回原 HTML
function renderMathInHtml(html) {
    const container = document.createElement('div');
    container.innerHTML = html;
    const nodes = collectFormulaTextNodes(container);
    if (nodes.length === 0) {
        return Promise.resolve({ html, rendered: 0, failed: 0 });
    }

    const run = async () => {
        let rendered = 0, failed = 0;
        for (const node of nodes) {
            const text = node.nodeValue;
            const matches = matchFormulas(text);
            const fragment = document.createDocumentFragment();
            let pos = 0;
            for (const match of matches) {
                if (match.start > pos) {
                    fragment.appendChild(document.createTextNode(text.slice(pos, match.start)));
                }
                try {
                    fragment.appendChild(await renderOneFormula(match.tex, match.display));
                    rendered++;
                } catch (err) {
                    console.warn('[html2article] 公式渲染失败，保留原文:', err.message, '->', text.slice(match.start, match.end));
                    fragment.appendChild(document.createTextNode(text.slice(match.start, match.end)));
                    failed++;
                }
                pos = match.end;
            }
            if (pos < text.length) {
                fragment.appendChild(document.createTextNode(text.slice(pos)));
            }
            node.parentNode.replaceChild(fragment, node);
        }
        return { html: container.innerHTML, rendered, failed };
    };

    // 串行化渲染批次，避免 MathJax 并发竞态
    const promise = mathQueue.then(run);
    mathQueue = promise.catch(() => {});
    return promise;
}
